import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'fibonacci';

Fibonacci()
        {
            let number=document.getElementById("textnumber").value;
            let t1=0,t2=1,nextterm;
            let resultstr="";
            for(let i=1;i<=number;++i)
            {
                resultstr=resultstr+t1;
                nextterm=t1+t2;
                t1=t2;
                t2=nextterm;
            }
          
           resultstr="Fibonacci of "+number+" is "+resultstr;
          document.getElementById("result").innerHTML=resultstr;
        }


}
