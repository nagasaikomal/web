import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'webapp-v2';
   num1:number;
   checkNumber():void{
    //this.num1= document.getElementById("txtnumber").value;
    if(this.num1 >0){
       document.getElementById("result").innerHTML="Number is Positive"
    }else{
      document.getElementById("result").innerHTML="Number is Negative"
    }
     
   }

}
