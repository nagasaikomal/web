import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'factorial';
  fact:number;
  factorial():void{
    let txt= document.getElementById("txtnumber").value;
   this.fact=1;
   let resultstr="";
   for(let i=2;i<=txt;i++)
   {
       this.fact=this.fact*i;
   }
          
   resultstr="Factorial of "+txt+" is "+this.fact;
   document.getElementById("result").innerHTML=resultstr;
    
  }
}
