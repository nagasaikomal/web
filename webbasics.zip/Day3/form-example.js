function validateForm(){
    var errorStr="<ul>";
    var flag=false;
    var empname=document.getElementById("empname").value;
    var empcode=document.getElementById("empcode").value;

    if(empname==""){
       errorStr =errorStr+"<li>Employee name is required.</li>";
       flag =true;
    }
    if(empcode==""){
        errorStr =errorStr+
        "<li>Employee code is required.</li>";
        flag =true;
    }

    var dept=document.getElementsByName("rad");
    var deptStatus=false;
    for(var i=0;i<dept.length;i++){
        if(dept[i].checked){
            deptStatus=true;
          
        }
    }
    if(!deptStatus){
        errorStr =errorStr +"<li>Please select Department.</li>";
        flag =true;
    }

    var day=document.getElementById("day");
    var daySelected =day.options[day.selectedIndex].value;
    if(daySelected == -1){
        errorStr=errorStr +"<li>Please select day</li>"
        flag =true;
    }

    errorStr=errorStr +"</ul>";
    if(flag)
    document.getElementById("error").innerHTML=errorStr;
    else
      document.getElementById("form").submit();
}